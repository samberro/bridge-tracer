### Phase 0: UX Mockups and Final UI Approval

* generate several UI mockup options first
* include mockups for:

  * main desktop timeline
  * timeline/filmstrip view
  * event detail inspector
  * filter/recording sidebar
* review mockups with the user
* revise mockups until approved
* after approval, create the final UI form/layout
* only the approved final form should guide implementation
* do not start PySide6 UI implementation until the final form is approved

### Mockup Prompt 1: Main Desktop Timeline UI

Create a high-fidelity desktop UI mockup for a tool called “Bridge Timeline Debugger”.

Goal: visually inspect events recorded from an AI bridge.

Layout:

* dark theme
* top toolbar with: Connect, Start Recording, Stop Recording, Save, Load
* token/auth status indicator
* left sidebar for pre-record and post-record filters
* center area shows a horizontal train-track / filmstrip timeline
* right panel shows selected event details
* bottom collapsible raw JSON/log panel

Timeline lanes:

* HTTP
* LLM
* Tool
* File
* Error
* Performance

Events should appear as compact colored nodes/cards. Summaries only until clicked. Show connections between related events. Use category colors: HTTP blue, LLM indigo, Tool orange, File green, Error red, Config gray, Auth purple.

Include realistic event examples:

* POST /api/send → 200 in 231ms
* LLM request: 12 messages, 4201 tokens
* Tool call: read_file(config.py)
* Tool result: 18,204 chars
* File ref retrieved: screenshot.png
* Error: JSON parse failed

Make it look like a serious developer debugging tool, not a toy.

### Mockup Prompt 2: Timeline / Filmstrip Focused

Design a detailed mockup focused only on the timeline view for an AI bridge debugger.

The timeline should look like a train-track or filmstrip with multiple horizontal lanes:

* HTTP
* LLM
* Tool
* File
* Parser
* Error

Each event is a small colored card/node on its lane. Related events are connected with thin lines. Parent events can expand to show child tool calls. Long events show duration bars. Errors are red and visually obvious.

Show compact summaries by default:

* HTTP POST /api/send
* LLM request sent
* LLM response received
* Tool call write_file
* Tool result success
* File ref retrieved
* Warning: max_tokens reached

Include controls above the timeline:

* zoom slider
* search
* category toggles
* show errors only
* collapse groups
* jump to selected run

Dark theme. Dense but readable. Built for debugging fast.

### Mockup Prompt 3: Event Detail Inspector

Create a mockup for the selected-event detail panel of a desktop AI bridge debugger.

The user clicked an event: “LLM response received”.

The right-side inspector should show:

* event summary
* event type/category/severity
* timestamp
* run_id/session_id/request_id
* duration
* token usage
* model name
* finish_reason
* raw response preview
* reasoning_content preview if present
* tool_calls if present
* related parent/child events
* file_refs list
* buttons: Copy JSON, Open File Ref, Compare Event, Pin Event

Include a bottom raw JSON viewer with syntax highlighting.

Dark theme. Developer-focused. Clear hierarchy. Make noisy payloads collapsible.

### Mockup Prompt 4: Filter / Recording Control UI

Design a left sidebar mockup for an AI bridge recording debugger.

The sidebar should include:

Connection section:

* Bridge URL input
* Bearer token input
* Save token checkbox
* Connect button
* auth status

Recording controls:

* Start Recording button
* Stop Recording button
* current state: idle / recording / stopping / stopped
* event count
* elapsed time

Pre-record filters:

* record everything
* only selected session
* only selected request/run
* only LLM traffic
* only tool calls
* only errors
* only file refs
* selected endpoints
* selected event categories

Recording triggers:

* manual start
* start when endpoint is hit
* start when session id appears
* start when error occurs
* start when tool is called
* start when selected model is used

Stop triggers:

* stop after N events
* stop after timeout
* stop after request/run completes
* stop on error

Post-record filters:

* search box
* category toggles
* show errors only
* show file refs only
* show tool calls only
* duration range

Dark theme. Compact, practical, similar to a professional debugging/profiling tool.