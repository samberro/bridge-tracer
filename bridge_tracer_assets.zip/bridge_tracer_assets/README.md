# Bridge Tracer Assets

High-fidelity Phase 0 UX mockups for the Bridge Timeline Debugger. Includes editable SVGs, PNG exports, preview sheet, and manifest.

Generated from `Prompts_Bridge Tracer.md`.
